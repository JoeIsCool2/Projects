import UIKit


func generateMadLib(noun1: String, adjective1: String, verb1: String, noun2: String, adjective2: String, verb2: String, noun3: String, adjective3: String, verb3: String, noun4: String, adjective4: String, verb4: String) -> String {
    
    
    
    var nouns = [noun1, noun2, noun3, noun4]
    if nouns.contains("") || nouns.contains(" ") {
        return "Invalid Input"
    } else {
        nouns.shuffle()
    }
        
    var adjectives = [adjective1, adjective2, adjective3, adjective4]
    if adjectives.contains("") || adjectives.contains(" ") {
        return "Invalid Input"
    } else {
        adjectives.shuffle()
    }
            
    var verbs = [verb1, verb2, verb3, verb4]
    if verbs.contains("") || verbs.contains(" ") {
        return "Invalid Input"
    } else {
        verbs.shuffle()
    }
    let randomStory = Int.random(in: 1...6)
    
    switch randomStory {
        case 1:
            return "Today, a \(adjectives[0]) \(nouns[0]) tried to \(verbs[0]) into a \(adjectives[1]) \(nouns[1]). Everyone was shocked when a \(adjectives[2]) \(nouns[2]) showed up and started to \(verbs[1]) loudly. In the chaos, the \(nouns[3]) just kept trying to \(verbs[2]) like nothing was wrong."
            
        case 2:
            return "At the park, the \(adjectives[0]) \(nouns[0]) thought it was a good idea to \(verbs[0]) on top of the \(adjectives[1]) \(nouns[1]). But then, a \(adjectives[2]) \(nouns[2]) appeared and began to \(verbs[1]) furiously. To make it even weirder, the \(adjectives[3]) \(nouns[3]) decided to join in and \(verbs[2]) too."
            
        case 3:
            return "Once upon a time, a \(adjectives[0]) \(nouns[0]) was bored and wanted to \(verbs[0]). It asked its best friend, the \(adjectives[1]) \(nouns[1]), to join. Just when things seemed normal, a \(adjectives[2]) \(nouns[2]) ran in and started to \(verbs[1]). The story ended with everyone watching the \(adjectives[3]) \(nouns[3]) trying to \(verbs[2]) in the background."
            
        case 4:
            return "During lunch, a \(adjectives[0]) \(nouns[0]) tried to \(verbs[0]) while eating a sandwich. Suddenly, a \(adjectives[1]) \(nouns[1]) crashed the table and began to \(verbs[1]). A crowd formed when a \(adjectives[2]) \(nouns[2]) rolled in to \(verbs[2]). Nobody noticed the \(adjectives[3]) \(nouns[3]) quietly sneaking away."
        case 5 :
            return "In the lab, a \(adjectives[0]) \(nouns[0]) was trying to \(verbs[0]) with a mysterious potion. Just as it added the final ingredient, a \(adjectives[1]) \(nouns[1]) burst through the door and began to \(verbs[1]) uncontrollably. The chaos escalated when a \(adjectives[2]) \(nouns[2]) flew in and started to \(verbs[2]) all over the equipment. Meanwhile, the \(adjectives[3]) \(nouns[3]) took notes like it was all perfectly normal."
        default:
            return "In a strange twist of events, a \(adjectives[0]) \(nouns[0]) decided to \(verbs[0]) across town. Along the way, it bumped into a \(adjectives[1]) \(nouns[1]) that started to \(verbs[1]) without warning. Things only got funnier when a \(adjectives[2]) \(nouns[2]) jumped in to \(verbs[2]), leaving the poor \(adjectives[3]) \(nouns[3]) wondering what just happened."
        }
}

print(generateMadLib(noun1: "Joe", adjective1: "fluffy", verb1: "sneeze", noun2: "toaster", adjective2: "angry", verb2: "juggle", noun3: "banana", adjective3: "tiny", verb3: "explode", noun4: "grandma", adjective4: "sparkly", verb4: "moonwalk"
))

